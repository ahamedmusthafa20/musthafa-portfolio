import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Mail, 
  Phone, 
  MapPin, 
  Github, 
  Linkedin, 
  Twitter, 
  ExternalLink,
  Code,
  Palette,
  GraduationCap,
  Award,
  Briefcase,
  User
} from "lucide-react";
import profileImage from "@/assets/profile-image.jpg";

const Portfolio = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: ""
  });
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Message sent!",
      description: "Thank you for your message. I'll get back to you soon.",
    });
    setFormData({ name: "", email: "", message: "" });
  };

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="glass-background cyber-grid">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 glass-nav z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="font-bold text-xl neon-text">Ahamed Musthafa</div>
            <div className="hidden md:flex space-x-8">
              {["Home", "About", "Education", "Experience", "Services", "Projects", "Achievements", "Contact"].map((item) => (
                <button 
                  key={item}
                  onClick={() => scrollToSection(item.toLowerCase())}
                  className="text-white/80 hover:text-neon-purple hover:drop-shadow-[0_0_8px_rgba(139,69,255,0.8)] transition-all duration-300"
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="section-padding pt-32 lg:pt-40 relative overflow-hidden">
        {/* Cyberpunk decorative elements */}
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-neon-purple rounded-full animate-pulse"></div>
          <div className="absolute top-1/3 right-1/3 w-1 h-1 bg-neon-violet rounded-full animate-pulse delay-700"></div>
          <div className="absolute bottom-1/3 left-1/3 w-1.5 h-1.5 bg-neon-purple rounded-full animate-pulse delay-1000"></div>
        </div>
        
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="animate-fade-in">
              <h1 className="text-5xl lg:text-6xl font-bold mb-6">
                Hi, I'm <span className="neon-text drop-shadow-[0_0_20px_rgba(139,69,255,0.8)]">Ahamed Musthafa</span>
              </h1>
              <p className="text-xl text-neon-violet mb-8 drop-shadow-[0_0_10px_rgba(139,69,255,0.3)]">
                Aspiring Full Stack Developer & UI/UX Designer
              </p>
              <p className="text-lg text-white/80 mb-8 max-w-md">
                B.Tech IT student passionate about creating beautiful, functional digital experiences and solving complex problems through code.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="glass-button" onClick={() => scrollToSection("projects")}>
                  View My Work
                </Button>
                <Button size="lg" className="glass-button" onClick={() => scrollToSection("contact")}>
                  Contact Me
                </Button>
              </div>
            </div>
            <div className="flex justify-center animate-slide-up">
              <div className="relative">
                <div className="absolute inset-0 rounded-full bg-gradient-to-r from-neon-purple to-neon-violet opacity-75 blur-xl animate-pulse"></div>
                <img 
                  src={profileImage} 
                  alt="Ahamed Musthafa - Profile Picture"
                  className="relative w-80 h-80 rounded-full object-cover shadow-2xl border-2 border-neon-purple/50"
                  style={{
                    filter: 'drop-shadow(0 0 20px rgba(139, 69, 255, 0.6))'
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="section-padding">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex justify-center mb-6">
            <User className="w-12 h-12 text-neon-purple drop-shadow-[0_0_15px_rgba(139,69,255,0.8)]" />
          </div>
          <h2 className="text-4xl font-bold mb-8 neon-text">About Me</h2>
          <div className="portfolio-card">
            <p className="text-lg text-white/90 leading-relaxed mb-6">
              I'm a passionate B.Tech IT student with a strong foundation in programming and design. 
              Skilled in Java, Python, HTML, CSS, and UI/UX Design using Figma, I love tackling 
              challenging problems and optimizing solutions.
            </p>
            <p className="text-lg text-white/90 leading-relaxed">
              My goal is to create user-friendly designs that not only look great but also provide 
              exceptional user experiences. I'm constantly learning and exploring new technologies 
              to expand my skill set and stay current with industry trends.
            </p>
          </div>
        </div>
      </section>

      {/* Education Section */}
      <section id="education" className="section-padding">
        <div className="max-w-4xl mx-auto">
          <div className="flex justify-center mb-6">
            <GraduationCap className="w-12 h-12 text-neon-purple drop-shadow-[0_0_15px_rgba(139,69,255,0.8)]" />
          </div>
          <h2 className="text-4xl font-bold text-center mb-12 neon-text">Education</h2>
          <div className="space-y-8">
            <Card className="portfolio-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  B.Tech in Information Technology
                  <Badge>2022 - 2026</Badge>
                </CardTitle>
                <CardDescription>M.A.M College of Engineering</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Currently pursuing Bachelor of Technology in Information Technology, 
                  focusing on software development, database management, and system design.
                </p>
              </CardContent>
            </Card>
            
            <Card className="portfolio-card">
              <CardHeader>
                <CardTitle>Higher Secondary Certificate (HSC)</CardTitle>
                <CardDescription>Completed with distinction</CardDescription>
              </CardHeader>
            </Card>
            
            <Card className="portfolio-card">
              <CardHeader>
                <CardTitle>Secondary School Leaving Certificate (SSLC)</CardTitle>
                <CardDescription>Strong foundation in mathematics and sciences</CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="section-padding">
        <div className="max-w-4xl mx-auto">
          <div className="flex justify-center mb-6">
            <Briefcase className="w-12 h-12 text-neon-purple drop-shadow-[0_0_15px_rgba(139,69,255,0.8)]" />
          </div>
          <h2 className="text-4xl font-bold text-center mb-12 neon-text">Experience</h2>
          <div className="space-y-8">
            <Card className="portfolio-card">
              <CardHeader>
                <CardTitle>UI/UX Design Intern</CardTitle>
                <CardDescription>Raavelsoft Technologies</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Worked on user interface design projects, created wireframes and prototypes, 
                  and collaborated with the development team to implement design solutions.
                </p>
              </CardContent>
            </Card>
            
            <Card className="portfolio-card">
              <CardHeader>
                <CardTitle>UI/UX Design Training</CardTitle>
                <CardDescription>iSQUARE's Digital Solutions</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Intensive training program covering design principles, user research, 
                  prototyping, and modern design tools including Figma and Adobe Creative Suite.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="section-padding">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12 neon-text">Services</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="portfolio-card">
              <CardHeader>
                <div className="flex items-center gap-3 mb-4">
                  <Palette className="w-8 h-8 text-white" />
                  <CardTitle>UI/UX Design</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-white/80">
                  <li>• Wireframing and prototyping</li>
                  <li>• User interface design</li>
                  <li>• User experience optimization</li>
                  <li>• Design system creation</li>
                  <li>• Figma design and collaboration</li>
                </ul>
              </CardContent>
            </Card>
            
            <Card className="portfolio-card">
              <CardHeader>
                <div className="flex items-center gap-3 mb-4">
                  <Code className="w-8 h-8 text-white" />
                  <CardTitle>Web Development</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-white/80">
                  <li>• HTML, CSS, and JavaScript</li>
                  <li>• Responsive web design</li>
                  <li>• Frontend development</li>
                  <li>• Basic backend integration</li>
                  <li>• Performance optimization</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="section-padding">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12 neon-text">Projects</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="portfolio-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  Campus Buddy App
                  <ExternalLink className="w-4 h-4" />
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-white/80 mb-4">
                  A comprehensive mobile app designed to help students navigate campus life, 
                  including features for course management, social networking, and campus resources.
                </p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">Mobile Design</Badge>
                  <Badge variant="secondary">UI/UX</Badge>
                </div>
              </CardContent>
            </Card>
            
            <Card className="portfolio-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  Foodly Web Redesign
                  <ExternalLink className="w-4 h-4" />
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-white/80 mb-4">
                  Complete redesign of a food delivery platform focusing on improved user experience, 
                  streamlined ordering process, and modern visual design.
                </p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">Web Design</Badge>
                  <Badge variant="secondary">Redesign</Badge>
                </div>
              </CardContent>
            </Card>
            
            <Card className="portfolio-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  HealthTrack Dashboard
                  <ExternalLink className="w-4 h-4" />
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-white/80 mb-4">
                  A comprehensive health monitoring dashboard with data visualization, 
                  user-friendly interface for tracking health metrics and generating reports.
                </p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">Dashboard</Badge>
                  <Badge variant="secondary">Data Viz</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Achievements Section */}
      <section id="achievements" className="section-padding">
        <div className="max-w-4xl mx-auto">
          <div className="flex justify-center mb-6">
            <Award className="w-12 h-12 text-neon-purple drop-shadow-[0_0_15px_rgba(139,69,255,0.8)]" />
          </div>
          <h2 className="text-4xl font-bold text-center mb-12 neon-text">Achievements & Certifications</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="portfolio-card">
              <CardHeader>
                <CardTitle>Full Stack Automation CI/CD</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-white/80">
                  Comprehensive certification in modern development workflows and deployment pipelines.
                </p>
              </CardContent>
            </Card>
            
            <Card className="portfolio-card">
              <CardHeader>
                <CardTitle>Python for Data Science</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-white/80">
                  Advanced certification in Python programming with focus on data analysis and machine learning.
                </p>
              </CardContent>
            </Card>
            
            <Card className="portfolio-card">
              <CardHeader>
                <CardTitle>UI/UX Design with Figma</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-white/80">
                  Professional certification in user interface and experience design using Figma.
                </p>
              </CardContent>
            </Card>
            
            <Card className="portfolio-card">
              <CardHeader>
                <CardTitle>Java Fundamentals</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-white/80">
                  Strong foundation certification in Java programming and object-oriented principles.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="section-padding">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12 neon-text">Contact Me</h2>
          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-semibold mb-6 text-white">Get in Touch</h3>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-white" />
                  <span className="text-white/90">ahamedmusthafa20304@gmail.com</span>
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="w-5 h-5 text-white" />
                  <span className="text-white/90">+91 9025895349</span>
                </div>
                <div className="flex items-center gap-3">
                  <MapPin className="w-5 h-5 text-white" />
                  <span className="text-white/90">Perambalur, Tamil Nadu, India</span>
                </div>
              </div>
              
              <div className="mt-8">
                <h4 className="text-lg font-medium mb-4 text-white">Follow Me</h4>
                <div className="flex gap-4">
                  <Button className="glass-button" size="icon">
                    <Github className="w-4 h-4" />
                  </Button>
                  <Button className="glass-button" size="icon">
                    <Linkedin className="w-4 h-4" />
                  </Button>
                  <Button className="glass-button" size="icon">
                    <Twitter className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
            
            <Card className="portfolio-card">
              <CardHeader>
                <CardTitle>Send a Message</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <Input 
                    placeholder="Your Name"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    required
                  />
                  <Input 
                    type="email"
                    placeholder="Your Email"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    required
                  />
                  <Textarea 
                    placeholder="Your Message"
                    rows={4}
                    value={formData.message}
                    onChange={(e) => setFormData({...formData, message: e.target.value})}
                    required
                  />
                  <Button type="submit" className="w-full glass-button">Send Message</Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-white/80">© 2025 Ahamed Musthafa. Built with Loveable AI.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Portfolio;